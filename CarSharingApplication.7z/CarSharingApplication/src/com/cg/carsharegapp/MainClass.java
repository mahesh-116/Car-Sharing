package com.cg.carsharegapp;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


import com.cg.carsharegapp.exception.VehicleNumberException;
import com.cg.carsharegapp.services.OwnerServicesImplements;
import com.cg.carsharengapp.dto.Address;
import com.cg.carsharengapp.dto.Owner;
import com.cg.carsharengapp.dto.Vehicle;

public class MainClass {

	public static void main(String[] args) {
	

		Scanner sc=new Scanner(System.in);


		OwnerServicesImplements ownerServices=new OwnerServicesImplements();


		System.out.println("**************Starting Functionality to find Owner************************");
		System.out.println("**********************************************************************");

		
		
		System.out.println("Enter owner name to search");
		String ownerName=sc.next();
		List<Owner> ownerSearch;
		
			ownerSearch = ownerServices.searchByName(ownerName);
		
		for(Owner ownerAll:ownerSearch)
		{
			System.out.println("Owner mobile Number:"+ownerAll.getMobile());
			System.out.println("Owner address is:"+ownerAll.getAddress());
			System.out.println("Owner vehicle information  is:"+ownerAll.getVehicles());
			System.out.println();
			System.out.println();
			
			   System.out.println();
			   
			   
			
		}
	
  System.out.println();
		System.out.println("**********************************************************************");
		System.out.println("**********************************************************************");
		
		System.out.println();

		System.out.println("Search Owner by Vehicle Model Name:");
		String modelName=sc.next();
		List<Owner> ownerSearchOne=ownerServices.searchByModelName(modelName);

		for(Owner ownerRef : ownerSearchOne){
			System.out.println(ownerRef.getName());
			System.out.println(ownerRef.getMobile());
			for(Vehicle veh:ownerRef.getVehicles()){
				if(veh.getModelName().equals(modelName))
				{
				 System.out.println(veh.getVehicleNumber());
				 System.out.println(veh.getType());
				
				}
			}
			System.out.println(ownerRef.getAddress());		
			System.out.println();
			System.out.println();
		}

		System.out.println("**********************************************************************");
		System.out.println("**********************************************************************");
		System.out.println();

		String strTwo="yes";
		do {
			
			System.out.println();
		System.out.println("Search Owner by Vehicle Number:");
		String vehicleNumber=sc.next();
		Owner ownerSearchRef;
		try {
			ownerSearchRef = ownerServices.searchByVehicleNumber(vehicleNumber);
		
		
	           System.out.println(ownerSearchRef.getName());
		       System.out.println(ownerSearchRef.getMobile());
		     for(Vehicle veh:ownerSearchRef.getVehicles())
		    {
			   if(veh.getVehicleNumber().equals(vehicleNumber))
			    {
			      System.out.println(veh.getModelName());
			      System.out.println(veh.getType());
			  }
		}
     System.out.println(ownerSearchRef.getAddress());
     System.out.println();
		} catch (VehicleNumberException e) {
		
			System.out.println(e.getMessage());
		}
	
     System.out.println();
     System.out.println("you want search another owner using vehicle number");
     strTwo=sc.next();
     
     
	}while(strTwo.equals("yes"));
		
		System.out.println();
		
		System.out.println("****************************EndGame**********************************");
		System.out.println("**********************************************************************");
	}

}
