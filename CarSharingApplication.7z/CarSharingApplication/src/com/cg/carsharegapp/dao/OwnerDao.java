package com.cg.carsharegapp.dao;

import java.util.List;

import com.cg.carsharegapp.exception.VehicleNumberException;
import com.cg.carsharengapp.dto.Owner;

public interface OwnerDao {
	
	public Owner save(Owner owner);
    public List<Owner> findByName(String name);
    public List<Owner> findByModelName(String modelName);
    public Owner findByVehicleNumber(String vehicleNumber);
   
}
