package com.cg.carsharegapp.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.carsharegapp.exception.VehicleNumberException;
import com.cg.carsharegapp.util.DButil;
import com.cg.carsharengapp.dto.Owner;
import com.cg.carsharengapp.dto.Vehicle;

public class OwnerDaoImplements implements OwnerDao {

	List<Owner> ownerData;
	public OwnerDaoImplements()
	{
		ownerData=new ArrayList<Owner>();
	}
	
	@Override
	public Owner save(Owner owner) {
		
		DButil.ownerList.add(owner);
		return owner;
	}

	@Override
	public List<Owner> findByName(String name) {
	
		List<Owner> ownerSearch=new ArrayList<Owner>();
		for(Owner owner:DButil.ownerList)
		if(owner.getName().equals(name))
				ownerSearch.add(owner);

		return ownerSearch;
	}

	@Override
	public List<Owner> findByModelName(String modelName) {
		
		List<Owner> ownerSearch=new ArrayList<Owner>();
        
      for(Owner ownerOne:DButil.ownerList)
        for(Vehicle veh:ownerOne.getVehicles())
        	if(veh.getModelName().equals(modelName))
        	ownerSearch.add(ownerOne);
     
	return ownerSearch;
	}

	@Override
	public Owner findByVehicleNumber(String vehicleNumber) {
		
		for(Owner owner:DButil.ownerList)
		for(Vehicle veh:owner.getVehicles())
			if(veh.getVehicleNumber().equals(vehicleNumber))
				return owner;
			
		return null;
	}

}
