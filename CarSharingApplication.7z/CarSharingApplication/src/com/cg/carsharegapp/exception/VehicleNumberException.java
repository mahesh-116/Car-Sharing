package com.cg.carsharegapp.exception;

public class VehicleNumberException extends Exception {
	
	public VehicleNumberException()
	{
	
	}

	
	public VehicleNumberException(String str)
	{
		super(str);
	}

}
