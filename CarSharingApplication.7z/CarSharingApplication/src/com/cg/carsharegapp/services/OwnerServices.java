package com.cg.carsharegapp.services;

import java.util.List;


import com.cg.carsharegapp.exception.VehicleNumberException;
import com.cg.carsharengapp.dto.Owner;

public interface OwnerServices {

	public Owner addOwner(Owner owner);
	public List<Owner> searchByName(String name);
	public List<Owner> searchByModelName(String modelName);
	public Owner searchByVehicleNumber(String vehicleNumber) throws VehicleNumberException;

}
