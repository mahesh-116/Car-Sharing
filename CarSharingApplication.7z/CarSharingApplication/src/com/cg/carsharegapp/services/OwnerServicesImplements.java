package com.cg.carsharegapp.services;

import java.util.List;

import com.cg.carsharegapp.dao.OwnerDaoImplements;

import com.cg.carsharegapp.exception.VehicleNumberException;
import com.cg.carsharengapp.dto.Owner;

public class OwnerServicesImplements implements OwnerServices {

	OwnerDaoImplements ownerDao;
	public OwnerServicesImplements()
	{
		ownerDao=new OwnerDaoImplements();
	}
	
	@Override
	public Owner addOwner(Owner owner) {
		
		return ownerDao.save(owner);
	}

	@Override
	public List<Owner> searchByName(String name)  {
    
		return ownerDao.findByName(name);
	}

	@Override
	public List<Owner> searchByModelName(String modelName) {
	
		return ownerDao.findByModelName(modelName);
	}

	@Override
	public Owner searchByVehicleNumber(String vehicleNumber)throws VehicleNumberException {
	 if( ownerDao.findByVehicleNumber(vehicleNumber)==null)
		 
	 {
		 throw new VehicleNumberException("Oooops.......entered Vehicle number not  found");
	 }
		 return ownerDao.findByVehicleNumber(vehicleNumber);

	}

}
