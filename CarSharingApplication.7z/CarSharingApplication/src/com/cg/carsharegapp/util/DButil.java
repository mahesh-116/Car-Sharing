package com.cg.carsharegapp.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.cg.carsharegapp.services.OwnerServicesImplements;
import com.cg.carsharengapp.dto.Address;
import com.cg.carsharengapp.dto.Owner;
import com.cg.carsharengapp.dto.Vehicle;

public class DButil {
	
	public static List<Owner> ownerList=new ArrayList<Owner>();
	
	static {
	
	List<Vehicle> vehicles=new ArrayList<Vehicle>();

	Vehicle vehicle1=new Vehicle("audi","mh12cp9158","car");
	Vehicle vehicle2=new Vehicle("honda","mh12mp9898","bike");
	Vehicle vehicle3=new Vehicle("r15","mh12po5074","bike");
	vehicles.add(vehicle1);
	vehicles.add(vehicle2);
	vehicles.add(vehicle3);

	Address address=new Address("manas","chinchwad",411039,"pune");

	Owner owner=new Owner("mahesh",new BigInteger("9552115360"),"mahi@gmail.com",vehicles,address);

	List<Vehicle> vehiclesOne=new ArrayList<Vehicle>();

	Vehicle vehicle11=new Vehicle("nexon","mh12bp0098","car");
	Vehicle vehicle22=new Vehicle("shine","mh12pn777","bike");

	vehiclesOne.add(vehicle11);
	vehiclesOne.add(vehicle22);


	Address addressOne=new Address("sohamniwas","bhosari",411048,"pune");

	Owner ownerOne=new Owner("mahadev",new BigInteger("9689031252"),"mahdev@gmail.com",vehiclesOne,addressOne);
	
	
	List<Vehicle> vehiclesTwo=new ArrayList<Vehicle>();

	Vehicle vehicle111=new Vehicle("bmw","mh12cp0158","car");
	Vehicle vehicle222=new Vehicle("maruti","mh12mp7868","car");
	Vehicle vehicle333=new Vehicle("discover","mh12po5174","bike");
	vehicles.add(vehicle111);
	vehicles.add(vehicle222);
	vehicles.add(vehicle333);

	Address addressTwo=new Address("7plumeria","punawale",411049,"pune");

	Owner ownerTwo=new Owner("mahesh",new BigInteger("9527378157"),"mahirathod@gmail.com",vehiclesTwo,addressTwo);

	OwnerServicesImplements ownerServices=new OwnerServicesImplements();
	ownerServices.addOwner(owner);
	ownerServices.addOwner(ownerOne);
	ownerServices.addOwner(ownerTwo);
	}

}
