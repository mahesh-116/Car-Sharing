package com.cg.carsharengapp.dto;

public class Address {

	private String buildingName;
	private String area;
	private int pinCode;
	private String city;
	
	public Address()
	{
		
	}

	public Address(String buildingName, String area, int pinCode, String city) {
		super();
		this.buildingName = buildingName;
		this.area = area;
		this.pinCode = pinCode;
		this.city = city;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [buildingName=" + buildingName + ", area=" + area + ", pinCode=" + pinCode + ", city=" + city
				+ "]";
	}
	
	
}
