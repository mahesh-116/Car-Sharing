package com.cg.carsharengapp.dto;

import java.math.BigInteger;
import java.util.List;

public class Owner {
	private String name;
	private BigInteger mobile;
	private String email;
	private List<Vehicle>vehicles;
	private Address address;  
	
	public Owner(){}

	public Owner(String name, BigInteger mobile, String email, List<Vehicle> vehicles, Address address) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.vehicles = vehicles;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getMobile() {
		return mobile;
	}

	public void setMobile(BigInteger mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Owner [name=" + name + ", mobile=" + mobile + ", email=" + email + ", vehicles=" + vehicles
				+ ", address=" + address + "]";
	}

	
	


}
