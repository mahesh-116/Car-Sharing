package com.cg.carsharengapp.dto;

public class Vehicle {

	private String modelName;
	private String vehicleNumber;
	private String type;
	
	public Vehicle()
	{
		
	}

	public Vehicle(String modelName, String vehicleNumber, String type) {
		super();
		this.modelName = modelName;
		this.vehicleNumber = vehicleNumber;
		this.type = type;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Vehicle [modelName=" + modelName + ", vehicleNumber=" + vehicleNumber + ", type=" + type + "]";
	}
	
	
}
