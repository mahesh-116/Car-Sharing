package com.cg.carsharegappjdbc.dao;

import java.util.List;

import com.cg.carsharegappjdbc.dto.Owner;
import com.cg.carsharegappjdbc.exception.CarSharingException;



public interface OwnerDao {

	public Owner save(Owner owner);
    public List<Owner> findByName(String name);
    public List<Owner> findByModelName(String modelName);
    public Owner findByVehicleNumber(String vehicleNumber);
}
