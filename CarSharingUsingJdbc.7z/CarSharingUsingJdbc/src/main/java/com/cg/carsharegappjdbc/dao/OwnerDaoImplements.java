package com.cg.carsharegappjdbc.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.carsharegappjdbc.dbutil.DBUtil;
import com.cg.carsharegappjdbc.dto.Address;
import com.cg.carsharegappjdbc.dto.Owner;
import com.cg.carsharegappjdbc.dto.Vehicle;
import com.cg.carsharegappjdbc.exception.CarSharingException;
import com.cg.carsharegappjdbc.query.JdbcQuery;


public class OwnerDaoImplements implements OwnerDao {

	public Owner save(Owner owner) {
	
		Connection conn;
		PreparedStatement psmt;
		ResultSet result;
		conn=DBUtil.getConnection();//connecting to the database
	
		
	
		
		try {
			
			String Query=JdbcQuery.insertValintoOwner;//query to insert value in database into owner table
			 psmt=conn.prepareStatement(Query);
		
			
			psmt.setString(1, owner.getName());//Setting value to the prepared Statement
			psmt.setBigDecimal(2,owner.getMobile());
			psmt.setString(3, owner.getEmail());
			psmt.executeUpdate();//owner information added to database into owner table
      
		
			
				String sql="select mobile from owner";
				BigDecimal mobile=null;
				psmt=conn.prepareStatement(sql);
				result=psmt.executeQuery();

				
		
			 String QueryTwo=JdbcQuery.insertValintoAdd;//query to insert value in database into address table
			  psmt=conn.prepareStatement(QueryTwo);
			
		
			  psmt.setBigDecimal(1, owner.getMobile());//Setting value to the prepared Statement
			  psmt.setString(2, owner.getAddress().getBuildingName());
			  psmt.setString(3,owner.getAddress().getArea());
			  psmt.setInt(4, owner.getAddress().getPinCode());
			  psmt.setString(5, owner.getAddress().getCity());
			  psmt.executeUpdate();//owner information added to database into address table
			  

		

		 	   String QueryOne=JdbcQuery.insertValintoVehicle;//query to insert value in database into vehicle table
		       psmt=conn.prepareStatement(QueryOne);
			
			  for(Vehicle veh:owner.getVehicles())
			  {
				  
			   psmt.setString(1, veh.getModelName());//Setting value to the prepared Statement
			   psmt.setString(2,veh.getVehicleNumber());
			   psmt.setString(3, veh.getType());
		       psmt.setBigDecimal(4,owner.getMobile());
		        psmt.executeUpdate();//owner information added to database into vehicle table
              
			  }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
	System.out.println(e);
		}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
			System.out.println(e);
			}
		}
		return owner;//return owner to service layer
	}

	public List<Owner> findByName(String name) {
		// TODO Auto-generated method stub
		Connection conn;
		PreparedStatement psmt;
		ResultSet result;
		conn=DBUtil.getConnection();//connecting to the database
		
		List<Owner> ownerList=new ArrayList<Owner>();
		String sql=JdbcQuery.queryForFindByName;//query for showing all information related to the owner name
		
		try {
			psmt=conn.prepareStatement(sql);
			psmt.setString(1, name);
			result=psmt.executeQuery();//checking By name owner name is there or not
			while(result.next())//if yes
			{
				BigDecimal mobile=result.getBigDecimal(1);//getting value from database store in bigdecimal
				String area=result.getString(2);
				String city=result.getString(3);
				String modelName=result.getString(4);
				
				Owner owner=new Owner();
				owner.setMobile(mobile);//adding bigdecimal value to owner
				
				Address address=new Address();
				address.setArea(area);
				address.setCity(city);
				owner.setAddress(address);//adding address to the owner
				
				
				Vehicle veh=new Vehicle();//creating vehicle object
				veh.setModelName(modelName);
				
				List<Vehicle> vehicleList=new ArrayList<Vehicle>();
				vehicleList.add(veh);//adding vehicle to vehicles list
				owner.setVehicles(vehicleList);//adding vehicle list to the owner
				
				
				ownerList.add(owner);//adding owner to the owner list
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		System.out.println(e);
		}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
		System.out.println(e);
			}
		}
		return ownerList;//return list of owner to service layer
	}

	public List<Owner> findByModelName(String modelName) {
		// TODO Auto-generated method stub
		Connection conn;
		PreparedStatement psmt;
		ResultSet result;
		conn=DBUtil.getConnection();//connecting to the database
		
		List<Owner> ownerList=new ArrayList<Owner>();
		String sql=JdbcQuery.queryforFindByModelName;//query for showing all information related to the particular model name
		
		try {
			psmt=conn.prepareStatement(sql);
			psmt.setString(1, modelName);
			result=psmt.executeQuery();
			while(result.next())
			{
				BigDecimal mobile=result.getBigDecimal(1);//getting value from database store in bigdecimal
				String name=result.getString(2);
				String vehicleNumber=result.getString(3);
				String type=result.getString(4);
				String area=result.getString(5);
				String city=result.getString(6);
				
				
				Owner owner=new Owner();
				
				owner.setMobile(mobile);//adding bigdecimal value to owner
				owner.setName(name);
			
				
				Address address=new Address();
				address.setArea(area);
				address.setCity(city);
				
				
				Vehicle veh=new Vehicle();//creating vehicle object
				veh.setVehicleNumber(vehicleNumber);
				veh.setType(type);
				
				List<Vehicle> vehicles=new ArrayList<Vehicle>();
				vehicles.add(veh);
				
				owner.setAddress(address);//adding address to the owner
				owner.setVehicles(vehicles);//adding vehicle list to the owner
				
				ownerList.add(owner);//adding owner to the owner list
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("not connected to database...");
		}
		finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
			System.out.println(e);
			}
		}
		return ownerList;//return list of owner to service layer
		
	}

	public Owner findByVehicleNumber(String vehicleNumber) {
		// TODO Auto-generated method stub
		Connection conn;
		PreparedStatement psmt;
		ResultSet result;
		conn=DBUtil.getConnection();//connecting to the database
		Owner owner=new Owner();
		String sql=JdbcQuery.queryForFindByVehicleNumber;//query for showing all information related to the vehicle number
	try {
		psmt=conn.prepareStatement(sql);
		psmt.setString(1, vehicleNumber);
		result=psmt.executeQuery();
		while(result.next())
		{
			BigDecimal mobile=result.getBigDecimal(1);//getting value from database store in bigdecimal
			String name=result.getString(2);
			String vehicleName=result.getString(3);
			String type=result.getString(4);
			String area=result.getString(5);
			String city=result.getString(6);
			
			owner.setMobile(mobile);//adding bigdecimal value to owner
			owner.setName(name);
		
			
			Address address=new Address();
			address.setArea(area);
			address.setCity(city);
			
			
			Vehicle veh=new Vehicle();
			veh.setVehicleNumber(vehicleNumber);
			veh.setType(type);
			
			List<Vehicle> vehicles=new ArrayList<Vehicle>();
			vehicles.add(veh);
			
			owner.setAddress(address);//adding address to the owner
			owner.setVehicles(vehicles);//adding vehicle list to the owner
			return owner;////return owner to service layer
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println(e);
	}finally {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
		
		return null;//returning null if vehicle number is not found
	}

}
