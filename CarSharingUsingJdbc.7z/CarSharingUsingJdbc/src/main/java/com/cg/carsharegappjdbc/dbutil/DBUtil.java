package com.cg.carsharegappjdbc.dbutil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	static Connection conn;
	
	public static Connection getConnection()
	{
		Properties prop=new Properties();
		try {
			InputStream it=new FileInputStream("src/main/resources/jdbc.properties");//adding the path of jdbc.properties to the FileInputStream
			prop.load(it);
			if(prop!=null)
			{
				String driver=prop.getProperty("jdbc.driver");//loading the driver here
				String url=prop.getProperty("jdbc.url");//url of the database 
				String name=prop.getProperty("jdbc.name");//username of your database
				String pass=prop.getProperty("jdbc.pass");//password of your database
				
				
				Class.forName(driver);
				
				conn=DriverManager.getConnection(url,name,pass);//Connecting to the database
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
		
		System.out.println(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
		System.out.println(e);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
		System.out.println(e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
	System.out.println(e);
		}
		return conn;
		
	}
}
