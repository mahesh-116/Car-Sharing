package com.cg.carsharegappjdbc.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

public class Address {

	private BigDecimal add_Mobile;//declaration of vehicle class members using private keyword
	private String buildingName;
	private String area;
	private int pinCode;
	private String city;
	
	public Address()//constructor without parameter
	{
		
	}

	public Address(String buildingName, String area, int pinCode, String city,BigDecimal add_Mobile) {//parameterized constructor
		super();
		this.buildingName = buildingName;
		this.area = area;
		this.pinCode = pinCode;
		this.city = city;
		this.add_Mobile=add_Mobile;
	}

	
	
	public BigDecimal getAdd_Mobile() {//getting the value of  add_Mobile
		return add_Mobile;
	}

	public void setAdd_Mobile(BigDecimal add_Mobile) {//setting the value of add_Mobile
		this.add_Mobile = add_Mobile;
	}

	public String getBuildingName() {//getting the value of  buildingName
		return buildingName;
	}

	public void setBuildingName(String buildingName) {//setting the value of buildingName
		this.buildingName = buildingName;
	}

	public String getArea() {//getting the value of  area
		return area;
	}

	public void setArea(String area) {//setting the value of area
		this.area = area;
	}

	public int getPinCode() {//getting the value of  pinCode
		return pinCode;
	}

	public void setPinCode(int pinCode) {//setting the value of pinCode
		this.pinCode = pinCode;
	}

	public String getCity() {//getting the value of  city
		return city;
	}

	public void setCity(String city) {//setting the value of city
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [add_Mobile=" + add_Mobile + ", buildingName=" + buildingName + ", area=" + area + ", pinCode="
				+ pinCode + ", city=" + city + "]";
	}

	
	
	

	
	
}
