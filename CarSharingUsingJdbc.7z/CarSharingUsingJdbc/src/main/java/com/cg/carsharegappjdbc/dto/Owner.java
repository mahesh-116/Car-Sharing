package com.cg.carsharegappjdbc.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;




public class Owner
{
	private String name;//declaration of vehicle class members using private keyword
	private BigDecimal mobile;
	private String email;
	private List<Vehicle>vehicles;
	private Address address;  
	
	public Owner(){}//constructor without parameter

	public Owner(String name, BigDecimal mobile, String email, List<Vehicle> vehicles, Address address) {//parameterized constructor
		super();
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.vehicles = vehicles;
		this.address = address;
	}

	public String getName() {//getting the value of  Name
		return name;
	}

	public void setName(String name) {//setting the value of Name
		this.name = name;
	}

	public BigDecimal getMobile() {//getting the value of  mobile
		return mobile;
	}

	public void setMobile(BigDecimal mobile) {//setting the value of mobile
		this.mobile = mobile;
	}

	public String getEmail() {//getting the value of  email
		return email;
	}

	public void setEmail(String email) {//setting the value of email
		this.email = email;
	}

	public List<Vehicle> getVehicles() {//getting the value of  vehicles
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {//setting the value of vehicles
		this.vehicles = vehicles;
	}

	public Address getAddress() {//getting the value of  address
		return address;
	}

	public void setAddress(Address address) {//setting the value of address
		this.address = address;
	}

	@Override
	public String toString() {
		return "Owner [name=" + name + ", mobile=" + mobile + ", email=" + email + ", vehicles=" + vehicles
				+ ", address=" + address + "]";
	}

	

}
