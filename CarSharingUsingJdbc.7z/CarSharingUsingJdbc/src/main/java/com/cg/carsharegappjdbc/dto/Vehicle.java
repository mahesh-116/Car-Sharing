package com.cg.carsharegappjdbc.dto;

import java.math.BigDecimal;

public class Vehicle {
	private String modelName;//declaration of vehicle class members using private keyword
	private String vehicleNumber;
	private String type;
  private BigDecimal veh_Mobile;
	
	public Vehicle()//Constructor without parameter
	{
		
	}

	public Vehicle(String modelName, String vehicleNumber, String type,BigDecimal veh_Mobile) {//parametrized constructor of vehicle
		super();
		this.modelName = modelName;
		this.vehicleNumber = vehicleNumber;
		this.type = type;
		this.veh_Mobile=veh_Mobile;
	}

	public String getModelName() {//getting the value of  modelName
		return modelName;
	}

	public void setModelName(String modelName) {//setting the value of modelName
		this.modelName = modelName;
	}

	public String getVehicleNumber() {//getting the value of vehicleNumber
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {//setting the value of vehicleNumber
		this.vehicleNumber = vehicleNumber;
	}

	public String getType() {//getting the value of type
		return type;
	}

	public void setType(String type) {//setting the value of type
		this.type = type;
	}
	
	

	public BigDecimal getVeh_Mobile() {//getting the value of veh_Mobile
		return veh_Mobile;
	}

	public void setVeh_Mobile(BigDecimal veh_Mobile) {//setting the value of veh_Mobile
		this.veh_Mobile = veh_Mobile;
	}

	@Override
	public String toString() {
		return "Vehicle [modelName=" + modelName + ", vehicleNumber=" + vehicleNumber + ", type=" + type
				+ ", veh_Mobile=" + veh_Mobile + "]";
	}


	
}
