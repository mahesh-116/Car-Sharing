package com.cg.carsharegappjdbc.query;

public class JdbcQuery {
	
	
 public static String insertValintoOwner="insert into owner values(?,?,?)";
 public static String insertValintoAdd="insert into address values(?,?,?,?,?)";
 public static String insertValintoVehicle="insert into vehicle values(?,?,?,?)";
 public static String queryForFindByName="select owner.mobile,address.area,address.city,vehicle.modelName from vehicle join owner on vehicle.mobile_num=owner.mobile join address on owner.mobile=address.mobile_no  where owner.name=?	";
 public static String queryforFindByModelName="select owner.mobile,owner.name,vehicle.vehicleNumber,vehicle.type,address.area,address.city from vehicle join owner on vehicle.mobile_num=owner.mobile join address on owner.mobile=address.mobile_no where vehicle.modelName=?";
 public static String queryForFindByVehicleNumber="select owner.mobile,owner.name,vehicle.modelName,vehicle.type,address.area,address.city from vehicle join owner on vehicle.mobile_num=owner.mobile join address on owner.mobile=address.mobile_no where vehicle.vehicleNumber=?";
 
}
