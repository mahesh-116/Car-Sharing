package com.cg.carsharegappjdbc.service;

import java.util.List;

import com.cg.carsharegappjdbc.dto.Owner;
import com.cg.carsharegappjdbc.exception.CarSharingException;



public interface OwnerServices {

	public Owner addOwner(Owner owner);
	public List<Owner> searchByName(String name) throws CarSharingException;
	public List<Owner> searchByModelName(String modelName) throws CarSharingException;
	public Owner searchByVehicleNumber(String vehicleNumber) throws CarSharingException;
}
