package com.cg.carsharegappjdbc.service;

import java.util.List;

import com.cg.carsharegappjdbc.dao.OwnerDaoImplements;
import com.cg.carsharegappjdbc.dto.Owner;
import com.cg.carsharegappjdbc.exception.CarSharingException;

public class OwnerServicesImplements implements OwnerServices{
	
	OwnerDaoImplements ownerDao=new OwnerDaoImplements();

	public Owner addOwner(Owner owner) {
		// TODO Auto-generated method stub
		return ownerDao.save(owner);
	}

	public List<Owner> searchByName(String name) throws CarSharingException {
		// TODO Auto-generated method stub
		if(ownerDao.findByName(name).isEmpty())
			throw new CarSharingException("this name owner is not available in this app.....");
		return ownerDao.findByName(name);
	}

	public List<Owner> searchByModelName(String modelName) throws CarSharingException {
		// TODO Auto-generated method stub
		if(ownerDao.findByModelName(modelName).isEmpty())
			throw new CarSharingException("This modelName vehicle is not presented.....");
		return ownerDao.findByModelName(modelName);
	}

	public Owner searchByVehicleNumber(String vehicleNumber) throws CarSharingException {
		// TODO Auto-generated method stub
		if( ownerDao.findByVehicleNumber(vehicleNumber)==null)
		
			throw new CarSharingException("Ooooops......Entered vehicle number in this application.");
	
		return ownerDao.findByVehicleNumber(vehicleNumber);
	}

}
