package comcg.carsharegappjpa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;

import comcg.carsharegappjpa.dbutil.DBUtil;
import comcg.carsharegappjpa.dto.Address;
import comcg.carsharegappjpa.dto.Owner;
import comcg.carsharegappjpa.dto.Vehicle;
import comcg.carsharegappjpa.exception.CarSharingException;
import comcg.carsharegappjpa.service.OwnerServiceImpl;



public class MyMainClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);


		OwnerServiceImpl ownerServices=new OwnerServiceImpl();//creating object of Owner service

   EntityManager em=DBUtil.getConnection();
		System.out.println("************Starting Functionality to adding and find Owner****************");
		System.out.println("**********************************************************************");
		
		int choice=0;
		do {
			
		System.out.println("Enter yor choice:");
		System.out.println("1.For Adding owner and his Details");
		System.out.println("2.Search Owner by name:");
		System.out.println("3.Search Owner By model Name");
		System.out.println("4.Search Owner by vehicle Number");
		choice=sc.nextInt();
		switch(choice)
		{
		
		case 1:
		System.out.println("Enter your name:");
		String name=sc.next();
		System.out.println("Enter your mobile number:");
		BigDecimal mobile=sc.nextBigDecimal();
		System.out.println("Enter your email address:");
       String email=sc.next();
       
       String str="yes";
       
       Vehicle vehicle=new Vehicle();//individual vehicle class
       List<Vehicle> vehicles=new ArrayList<Vehicle>();//List of vehicles
       
       do {
       System.out.println("Enter your vehicle model name");
       String modelName=sc.next();
       System.out.println("Enter your vehicle number");
       String vehicleNumber=sc.next();
       System.out.println("Enter vehicle type");
       String type=sc.next();

	    
	    vehicle.setModelName(modelName);//setting value to the vehicles by user entered
	    vehicle.setVehicleNumber(vehicleNumber);
	    vehicle.setType(type);

	    vehicles.add(vehicle);//adding individual vehicle to list of vehicles

	    System.out.println("do you have another vehicle that have to insert:");
	    str=sc.next();
       }while(str.equalsIgnoreCase("yes"));//if we want to add more than one vehicle


	    System.out.println("Enter your building Name:");//Address related information
	    String buildingName=sc.next();
	    System.out.println("Enter your area:");
	    String area=sc.next();
	    System.out.println("Enter your pinCode:");
	    int pinCode=sc.nextInt();
	    System.out.println("Enter your city:");
	    String city=sc.next();
	    
	    
	    Address address=new Address();//creating object of address
	    address.setBuildingName(buildingName);
	    address.setArea(area);//setting value to address
	    address.setPinCode(pinCode);
	    address.setCity(city);

	    
       Owner owner=new Owner();//creating object of owner
       owner.setName(name);
       owner.setMobile(mobile);//setting value to owner
       owner.setEmail(email);
       owner.setAddress(address);//adding address all info to the owner 
       owner.setVehicles(vehicles);//adding vehicles to the owner
       
    
       
       
       
       
       ownerServices.addOwner(owner);//passing owner object to the service layer
       System.out.println();
       
   	System.out.println("**********************************************************************");
	System.out.println("**********************************************************************");
		
		break;
		
		case 2:
		System.out.println("Enter owner name to search");
		String ownerName=sc.next();
		List<Owner> ownerSearch;
		
		
				
					ownerSearch = ownerServices.searchByName(ownerName);
			
		
		for(Owner ownerAll:ownerSearch)//we are accessing list owner so we are using forEach
		{
			System.out.println("Owner mobile Number:"+ownerAll.getMobile());//getting value from individual owner object
			System.out.println("Owner address is:"+ownerAll.getAddress().getArea());
			System.out.println("Owner address is:"+ownerAll.getAddress().getCity());
			for(Vehicle veh:ownerAll.getVehicles())
			System.out.println("Owner vehicle information  is:"+veh.getModelName());
			System.out.println();
			System.out.println();
			
			   System.out.println();
			   
			   
			
		}	
				
  System.out.println();
		System.out.println("**********************************************************************");
		System.out.println("**********************************************************************");
		
		System.out.println();
break;

		case 3:
		System.out.println("Search Owner by Vehicle Model Name:");
		String modelName=sc.next();
	
		List<Owner> ownerSearchOne;
	
			ownerSearchOne = ownerServices.searchByModelName(modelName);//passing to the service layer and return from service layer storing value to list of owner
	

		for(Owner ownerRef : ownerSearchOne){
			System.out.println(ownerRef.getMobile());//getting value from individual owner object
			System.out.println(ownerRef.getName());
		 System.out.println(ownerRef.getAddress().getArea());
	     System.out.println(ownerRef.getAddress().getCity());
		

		}
			System.out.println();
			System.out.println();
	

		System.out.println("**********************************************************************");
		System.out.println("**********************************************************************");
		System.out.println();
		
		break;

		case 4:
			
			System.out.println();
		System.out.println("Search Owner by Vehicle Number:");
		String vehicleNumber=sc.next();
	
		Owner ownerSearchRef;
		try {
			
			
			ownerSearchRef = ownerServices.searchByVehicleNumber(vehicleNumber);//passing to the service layer and return from service layer storing value to  the owner
		
			  System.out.println(ownerSearchRef.getMobile());
	           System.out.println(ownerSearchRef.getName());
	           System.out.println(ownerSearchRef.getAddress().getArea());//getting value from individual owner object
	           System.out.println(ownerSearchRef.getAddress().getCity());
		     for(Vehicle vehTwo:ownerSearchRef.getVehicles())
		    {
			   if(vehTwo.getVehicleNumber().equals(vehicleNumber))
			    {
			      System.out.println(vehTwo.getModelName());
			      System.out.println(vehTwo.getType());
			  }
		}

     System.out.println();
		} catch (Exception e) {
		
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("Find by vehicle number finish...");
		}
	
 
		
		System.out.println();
		break;
		case 5:
		
		System.out.println("****************************EndGame**********************************");
		System.out.println("**********************************************************************");
		System.exit(0);
		break;
		
		
		default:
			
			System.out.println("wrong choice:");
			break;
		}
		}while(choice!=5);

	}
	}


