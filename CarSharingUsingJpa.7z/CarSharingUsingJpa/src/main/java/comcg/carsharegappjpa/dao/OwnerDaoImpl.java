package comcg.carsharegappjpa.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import comcg.carsharegappjpa.dbutil.DBUtil;
import comcg.carsharegappjpa.dto.Address;
import comcg.carsharegappjpa.dto.Owner;
import comcg.carsharegappjpa.dto.Vehicle;

public class OwnerDaoImpl implements OwnerDaoIntr {
EntityManager em;
  
public OwnerDaoImpl ()
{
	em=DBUtil.getConnection();
}

 
	public Owner save(Owner owner) {
		// TODO Auto-generated method stub
		
		owner.setName(owner.getName());
		owner.setMobile(owner.getMobile());
		owner.setEmail(owner.getEmail());
		
		
	   owner.getAddress().getBuildingName();
	
		
	
		List<Vehicle> vehicles=new ArrayList<Vehicle>();
		if(vehicles!=null)
		{
		   for(Vehicle vehicle:owner.getVehicles())
		  {
		   vehicle.setModelName(vehicle.getModelName());
		   vehicle.setVehicleNumber(vehicle.getVehicleNumber());
		   vehicle.setType(vehicle.getType());
		   vehicle.setVeh_Mobile(owner.getMobile());
		
		  em.persist(vehicle);

		  vehicles.add(vehicle);
		}
		}
		
		Address address=new Address();
		address.setAdd_Mobile(owner.getMobile());
		address.setBuildingName(owner.getAddress().getBuildingName());
		address.setArea(owner.getAddress().getArea());
		address.setPinCode(owner.getAddress().getPinCode());
		address.setCity(owner.getAddress().getCity());
		
		owner.setVehicles(vehicles);
		owner.setAddress(address);
		
	
		em.persist(address);
		em.persist(owner);
		
		em.getTransaction().commit();
		return owner;
	}

	public List<Owner> findByName(String name) {
		// TODO Auto-generated method stub
		
		Owner owner=new Owner();
		List<Owner> ownerList=new ArrayList<Owner>();
		
		
		TypedQuery<Owner> query=em.createQuery("select o from Owner o where name=?",Owner.class);
		query.setParameter(1, name);
		ownerList=  query.getResultList();
		return ownerList;
	}

	public List<Owner> findByModelName(String modelName) {
		// TODO Auto-generated method stub
		

		
		List<Vehicle> vehicleList = new ArrayList<Vehicle>();
		List<Owner> ownerList = new ArrayList<Owner>();
		
		List<Owner> ownerListOne = new ArrayList<Owner>();
		
		TypedQuery<Owner> query = em.createQuery("select o from Owner o", Owner.class);
		ownerList = query.getResultList();
		for (Owner owner : ownerList) {
			vehicleList = owner.getVehicles();
			for (Vehicle vehicle :vehicleList) {
				if(modelName.equals(vehicle.getModelName())) {
					ownerListOne.add(owner);
				}
				
			}
			
		}
		
		
 
 

		return ownerListOne;
	}

	public Owner findByVehicleNumber(String vehicleNumber) {
		// TODO Auto-generated method stub
	List<Owner> owner=new ArrayList<Owner>();
	List<Vehicle> vehicleList = new ArrayList<Vehicle>();
	TypedQuery<Owner> query=em.createQuery("select o from Owner o ",Owner.class);
	owner= query.getResultList();
	for(Owner ownerOne:owner)
	{
	vehicleList=ownerOne.getVehicles();
	for(Vehicle vehicle:vehicleList)
	 if(vehicleNumber.equals(vehicle.getVehicleNumber()))
		 return ownerOne;
	}
	return null;
	
	}

}
