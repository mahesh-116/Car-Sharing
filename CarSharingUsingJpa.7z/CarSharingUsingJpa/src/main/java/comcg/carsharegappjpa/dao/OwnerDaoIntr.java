package comcg.carsharegappjpa.dao;

import java.util.List;

import comcg.carsharegappjpa.dto.Owner;



public interface OwnerDaoIntr {
	

	public Owner save(Owner owner);
    public List<Owner> findByName(String name);
    public List<Owner> findByModelName(String modelName);
    public Owner findByVehicleNumber(String vehicleNumber);

}
