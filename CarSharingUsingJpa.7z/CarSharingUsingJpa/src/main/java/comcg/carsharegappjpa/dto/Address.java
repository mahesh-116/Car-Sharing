package comcg.carsharegappjpa.dto;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Address {
@Id
@Column(name="add_mobile")
	private BigDecimal add_Mobile;
@Column(name="buildingName")
	private String buildingName;
@Column(name="area")
	private String area;
@Column(name="pinCode")
	private int pinCode;
@Column(name="city")
	private String city;
	
	public Address()
	{
		
	}

	public Address(String buildingName, String area, int pinCode, String city,BigDecimal add_Mobile) {//
		super();
		this.buildingName = buildingName;
		this.area = area;
		this.pinCode = pinCode;
		this.city = city;
		this.add_Mobile=add_Mobile;
	}

	
	
	public BigDecimal getAdd_Mobile() {
		return add_Mobile;
	}

	public void setAdd_Mobile(BigDecimal add_Mobile) {
		this.add_Mobile = add_Mobile;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [add_Mobile=" + add_Mobile + ", buildingName=" + buildingName + ", area=" + area + ", pinCode="
				+ pinCode + ", city=" + city + "]";
	}

	
	
	
}
