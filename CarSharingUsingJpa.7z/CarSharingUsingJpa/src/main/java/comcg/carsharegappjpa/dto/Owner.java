package comcg.carsharegappjpa.dto;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class Owner {
	@Column(name="name")
	private String name;
	@Id
	@Column(name="mobile")
	private BigDecimal mobile;
	@Column(name="email")
	private String email;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="mobile")
	private List<Vehicle>vehicles;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Address address;  
	
	public Owner(){}

	public Owner(String name, BigDecimal mobile, String email, List<Vehicle> vehicles, Address address) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.vehicles = vehicles;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getMobile() {
		return mobile;
	}

	public void setMobile(BigDecimal mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Owner [name=" + name + ", mobile=" + mobile + ", email=" + email + ", vehicles=" + vehicles
				+ ", address=" + address + "]";
	}

	

}
