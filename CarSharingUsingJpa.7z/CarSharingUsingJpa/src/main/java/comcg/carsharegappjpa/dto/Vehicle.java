package comcg.carsharegappjpa.dto;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Vehicle {
	@Column(name="modelName")
	private String modelName;
	@Id
	@Column(name="vehicleNumber")
	private String vehicleNumber; 
	@Column(name="type")
	private String type;

	@Column(name="" )
  private BigDecimal veh_Mobile;
	

	
	public Vehicle()
	{
		
	}

	public Vehicle(String modelName, String vehicleNumber, String type,BigDecimal veh_Mobile) {//
		super();
		this.modelName = modelName;
		this.vehicleNumber = vehicleNumber;
		this.type = type;
		this.veh_Mobile=veh_Mobile;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	

	public BigDecimal getVeh_Mobile() {
		return veh_Mobile;
	}

	public void setVeh_Mobile(BigDecimal veh_Mobile) {
		this.veh_Mobile = veh_Mobile;
	}

	@Override
	public String toString() {
		return "Vehicle [modelName=" + modelName + ", vehicleNumber=" + vehicleNumber + ", type=" + type
				+ ", veh_Mobile=" + veh_Mobile + "]";
	}



}
