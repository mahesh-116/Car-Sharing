package comcg.carsharegappjpa.exception;

public class CarSharingException extends Exception {

	public CarSharingException()
	{
		super();
	}
	
	
	public CarSharingException(String str)
	{
		super(str);
	}
}
