package comcg.carsharegappjpa.service;

import java.util.List;

import comcg.carsharegappjpa.dao.OwnerDaoImpl;
import comcg.carsharegappjpa.dto.Owner;

public class OwnerServiceImpl implements OwnerServiceInter{

	OwnerDaoImpl  ownerDao=new  OwnerDaoImpl();
	public Owner addOwner(Owner owner) {
		// TODO Auto-generated method stub
		return ownerDao.save(owner);
	}

	public List<Owner> searchByName(String name) {
		// TODO Auto-generated method stub
		return ownerDao.findByName(name);
	}

	public List<Owner> searchByModelName(String modelName) {
		// TODO Auto-generated method stub
		return ownerDao.findByModelName(modelName);
	}

	public Owner searchByVehicleNumber(String vehicleNumber) {
		// TODO Auto-generated method stub
		return ownerDao.findByVehicleNumber(vehicleNumber);
	}

}
