package comcg.carsharegappjpa.service;

import java.util.List;

import comcg.carsharegappjpa.dto.Owner;
import comcg.carsharegappjpa.exception.CarSharingException;

public interface OwnerServiceInter {

	public Owner addOwner(Owner owner);
	public List<Owner> searchByName(String name) throws CarSharingException;
	public List<Owner> searchByModelName(String modelName);
	public Owner searchByVehicleNumber(String vehicleNumber) throws CarSharingException;
	
}
