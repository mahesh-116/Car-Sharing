package com.cg.carsharingusingspringboot.CarSharingUsingSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarSharingUsingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarSharingUsingSpringBootApplication.class, args);
	}

}
