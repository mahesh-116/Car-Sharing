package com.cg.productspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productspringboot.dto.Inventory;
import com.cg.productspringboot.dto.Product;
import com.cg.productspringboot.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	ProductService service;
	@RequestMapping(value="/add",method=RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Product>addProduct(@RequestBody Product pro)
	{
		Product prod=service.addProduct(pro);
		if(prod==null)
		{
			return new ResponseEntity("Product not Added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(prod,HttpStatus.OK);
	}
	@RequestMapping(value="/show",method=RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Product>> showAllProduct()
	{
		List<Product>mylist=service.showAll();
		if(mylist.isEmpty())
		{
			return new ResponseEntity("Product not Added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(mylist,HttpStatus.OK);
	}
	@RequestMapping(value="/search",method=RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Product>> showAllProduct(@RequestParam("name") String name)
	{
		List<Product>mylist=service.showAll();
		if(mylist.isEmpty())
		{
			return new ResponseEntity("Product not Added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(mylist,HttpStatus.OK);
	}
	
	@RequestMapping(value="/addall",method=RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Product>addAll(@ModelAttribute Product prod)
	{
		
		
		Product pro=service.addProduct(prod);
		if(pro==null)
		{
			return new ResponseEntity("Product not Added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(prod,HttpStatus.OK);
	}	
	
}
