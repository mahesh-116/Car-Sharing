package com.cg.productspringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productspringboot.dao.ProductDao;
import com.cg.productspringboot.dto.Product;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductDao dao;
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return dao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public List<Product> search(String name) {
		// TODO Auto-generated method stub
		return dao.findByName(name);
	}

}
