package com.cg.springmvcdemoone.controller;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcdemoone.dto.Product;
import com.cg.springmvcdemoone.service.ProductServiceImpl;

@Controller
public class ProductController {

	
	@Autowired
	ProductServiceImpl productService;
	//@RequestMapping(name="login" ,method=RequestMethod.GET)
	@GetMapping("login")
	public String loginPage()
	{
		return "mylogin";
		
	}
	
	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass)
	{
		if(user.equals("admin") && pass.equals("123456"))
			return "listPage";
		else
		return "error";
		
	}
	
	@GetMapping("addpage")
	public ModelAndView getAddProduct(@ModelAttribute("prod") Product pro)
	{
		List<String> listOfCategory=new ArrayList<String>();
		listOfCategory.add("elect");
		listOfCategory.add("grocery");
		listOfCategory.add("cloths");
		return new ModelAndView("addproduct","cato",listOfCategory);
	}
	
	@GetMapping("showpage")
	public ModelAndView showProduct()
	{
		List<Product> myAllProduct=productService.showAll();
		return new ModelAndView("showAll","showproduct",myAllProduct);
		
	}
	
	@PostMapping("addproduct")
	public ModelAndView addProduct(@ModelAttribute("prod") Product pro)
	{
		Product product=productService.addProduct(pro);
		return new ModelAndView("sucess","key",product);
		
	}
}
