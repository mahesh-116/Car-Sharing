package com.cg.springmvcdemoone.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.springmvcdemoone.dao.ProductDaoImpl;
import com.cg.springmvcdemoone.dto.Product;

@Service
public class ProductServiceImpl implements ProductServiceInter{

	 ProductDaoImpl dao=new ProductDaoImpl();
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return dao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

}
