
import{ Component} from '@angular/core';
@Component({
    selector:'add',
    templateUrl:'app.addproduct.html'
})


export class AddProduct{

}