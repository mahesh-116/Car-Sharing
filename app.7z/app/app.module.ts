﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {Routes,RouterModule} from '@angular/router';
import { ShowProduct } from './app.showproduct';
import { UpdateProduct } from './app.updateproduct';
import { SearchProduct } from './app.searchproduct';
import {AddProduct} from './app.addproduct';


const route:Routes=[
    {path:"",redirectTo:"show",pathMatch:"full"},
    {path:"add",component:AddProduct},
    {path:"show",component:ShowProduct},
    {path:"update",component:UpdateProduct},
    {path:"search",component:SearchProduct},
    {path:"search/:id",component:SearchProduct}
];
@NgModule({
    imports: [
        BrowserModule,RouterModule.forRoot(route)
        
    ],
    declarations: [
        AppComponent,AddProduct,ShowProduct,SearchProduct,UpdateProduct
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }

