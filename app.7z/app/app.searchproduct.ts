import{ Component} from '@angular/core';
import{ ActivatedRoute,Params} from '@angular/router';
@Component({
    selector:'search',
    templateUrl:'app.searchproduct.html'
})


export class SearchProduct{
    constructor(private activate:ActivatedRoute){

    }
    mydata:any;
  ngOnInit(){
    this.mydata=this.activate.snapshot.params['id'];
  }
}