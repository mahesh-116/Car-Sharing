import{ Component} from '@angular/core';
@Component({
    selector:'update',
    templateUrl:'app.updateproduct.html'
})


export class UpdateProduct{

}